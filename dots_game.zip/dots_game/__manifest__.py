# -*- coding: utf-8 -*-
{
    'name': "Dots and Boxes Game",
    'summary': """Dots and Boxes Game""",
    'description': """""",
    'category': 'Uncategorized',
    'version': '13.1',
    'depends': ['base','mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/players_profile.xml',
        'views/match_details.xml',
        'views/configuration.xml',
        'views/menuitems.xml',
    ],
    'demo': [
        'demo/demo.xml',
    ],
}
